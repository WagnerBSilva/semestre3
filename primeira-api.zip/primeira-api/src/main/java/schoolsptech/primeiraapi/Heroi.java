package schoolsptech.primeiraapi;

public class Heroi {
    private String nome;
    private int idade;
    private String habilidade;
    private int forca;


    private boolean vivo;

    public Heroi() {
    }

    public Heroi(String nome, int idade, String habilidade, int forca, boolean vivo) {
        this.nome = nome;
        this.idade = idade;
        this.habilidade = habilidade;
        this.forca = forca;
        this.vivo = vivo;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public String getHabilidade() {
        return habilidade;
    }

    public int getForca() {
        return forca;
    }

    public boolean isVivo() {
        return vivo;
    }
}
