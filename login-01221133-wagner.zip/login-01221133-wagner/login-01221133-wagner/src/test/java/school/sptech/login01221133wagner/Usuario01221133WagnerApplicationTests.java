package school.sptech.login01221133wagner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Usuario01221133WagnerApplicationTests {

	@Test
	void contextLoads() {
	}

}
