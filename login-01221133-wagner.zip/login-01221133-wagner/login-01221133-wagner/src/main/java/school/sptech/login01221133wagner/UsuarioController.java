package school.sptech.login01221133wagner;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {
    private List<Usuario> usuario;


    @GetMapping
    public List<Usuario> lista(){
        return usuario;
    }

    @PostMapping
    public Usuario cadastrar(@RequestBody Usuario novoUsuario){
        usuario.add(novoUsuario);
        return novoUsuario;
    }

    @PostMapping("/autenticacao/{usuario}/{senha}")
    public Usuario autenticar(@PathVariable Usuario usuario, @PathVariable Usuario senha){
        
    }
}
