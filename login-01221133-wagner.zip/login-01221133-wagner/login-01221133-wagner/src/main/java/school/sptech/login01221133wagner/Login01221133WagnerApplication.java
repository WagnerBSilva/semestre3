package school.sptech.login01221133wagner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Login01221133WagnerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Login01221133WagnerApplication.class, args);
	}

}
