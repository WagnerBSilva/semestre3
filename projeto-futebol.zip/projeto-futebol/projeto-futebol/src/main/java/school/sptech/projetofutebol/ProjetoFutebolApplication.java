package school.sptech.projetofutebol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoFutebolApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoFutebolApplication.class, args);
	}

}
