package school.sptech.projetofutebol.entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Treinador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;

    private String titulos;

    private String nacionalidade;

    private Boolean passagemPorSelecao;

    @OneToMany(mappedBy = "treinador")
    private List<Clube> clubes;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTitulos() {
        return titulos;
    }

    public void setTitulos(String titulos) {
        this.titulos = titulos;
    }

    public String getNacionalidade() {
        return nacionalidade;
    }

    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

    public Boolean getPassagemPorSelecao() {
        return passagemPorSelecao;
    }

    public void setPassagemPorSelecao(Boolean passagemPorSelecao) {
        this.passagemPorSelecao = passagemPorSelecao;
    }

    public List<Clube> getClubes() {
        return clubes;
    }

    public void setClubes(List<Clube> clubes) {
        this.clubes = clubes;
    }
}
