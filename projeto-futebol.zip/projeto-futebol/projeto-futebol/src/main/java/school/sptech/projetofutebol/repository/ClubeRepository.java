package school.sptech.projetofutebol.repository;

import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.ProblemDetail;
import school.sptech.projetofutebol.dto.ClubeDto;
import school.sptech.projetofutebol.entity.Clube;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ClubeRepository extends JpaRepository<Clube, Long> {

    Optional<Clube> findByNome(String nome);

    List<Clube> findByTreinadorNomeContainsIgnoreCase(String nome);

    List<Clube> findByDataCriacaoClubeLessThanEqual(LocalDate data);

    @Query("SELECT new school.sptech.projetofutebol.dto.ClubeDto(c.nome,c.treinador.nome) FROM Clube c")
    List<ClubeDto> listagemDto();

    @Transactional
    @Modifying
    @Query("DELETE FROM Clube c WHERE c.id = :id")
    void deletaPorId(Long id);

    @Transactional
    @Modifying
    @Query("UPDATE Clube c set c.nome = :nome WHERE c.id = :id")
    void atualizaNomePorId(Long id, String nome);
}
