package school.sptech.projetofutebol.controller;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import school.sptech.projetofutebol.dto.ClubeDto;
import school.sptech.projetofutebol.entity.Clube;
import school.sptech.projetofutebol.repository.ClubeRepository;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/clubes")
public class ClubeController {

    @Autowired
    private ClubeRepository clubeRepository;

    @PostMapping
    public ResponseEntity<Clube> cadastrar(@RequestBody Clube clube){
        Clube clubeRegistrado = this.clubeRepository.save(clube);

        return ResponseEntity.status(200).body(clubeRegistrado);
    }

    @GetMapping
    public ResponseEntity<List<Clube>> listar(){
    List<Clube> clubes = this.clubeRepository.findAll();

    if(clubes.isEmpty()){
    return ResponseEntity.status(204).build();
    }
        return ResponseEntity.status(200).body(clubes);
    }

    @GetMapping("{id}")
    public ResponseEntity<Clube> buscarPorId(@PathVariable long id){
    return ResponseEntity.of(this.clubeRepository.findById(id));
    }

    @GetMapping("/nome")
    public ResponseEntity<Clube> buscarPorNome(@RequestParam String nome){
    return ResponseEntity.of(this.clubeRepository.findByNome(nome));
    }

    @GetMapping("/treinador")
    public ResponseEntity<List<Clube>> buscarPorTreinador(@RequestParam String treinador){
    List<Clube> clubesFiltrados = this.clubeRepository.findByTreinadorNomeContainsIgnoreCase(treinador);

    if(clubesFiltrados.isEmpty()){
        return ResponseEntity.status(204).build();
    }
    return ResponseEntity.status(200).body(clubesFiltrados);
    }

    @GetMapping("/periodo/{data}")
    public ResponseEntity<List<Clube>> buscarPorDiretor(@PathVariable LocalDate data) {

        List<Clube> clubesFiltrados =
                this.clubeRepository.findByDataCriacaoClubeLessThanEqual(data);

        if (clubesFiltrados.isEmpty()) {
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(clubesFiltrados);
    }

    @GetMapping("/resumo")
    public ResponseEntity<List<ClubeDto>> retornaClubeResumo(){
        List<ClubeDto> clubes = this.clubeRepository.listagemDto();
        if(clubes.isEmpty()){
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(clubes);
    }

    @PostMapping
    public ResponseEntity<ClubeDto> cadastrarClubeDto(@RequestBody Clube clube){

        Clube clubeRegistrado = this.clubeRepository.save(clube);

//        return ResponseEntity.status(200).body(clubeRegistrado);

        return ResponseEntity.status(404).build();
    }

    @Transactional
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarPorId(@PathVariable Long id){
        if(this.clubeRepository.existsById(id)){
            this.clubeRepository.deletaPorId(id);
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(404).build();
    }

    @Transactional
    @PatchMapping("/{id}")
    public ResponseEntity<Void> atualizaNovoNome(@PathVariable Long id, @RequestParam String nome){
        if(this.clubeRepository.existsById(id)){
            this.clubeRepository.atualizaNomePorId(id, nome);
            return ResponseEntity.status(200).build();
        }
        return ResponseEntity.status(404).build();
    }


}
