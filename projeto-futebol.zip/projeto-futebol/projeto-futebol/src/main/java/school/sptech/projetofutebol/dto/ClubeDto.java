package school.sptech.projetofutebol.dto;

import java.time.LocalDate;

public class ClubeDto {

    private String nome;

    private String treinador;

    private LocalDate dataCriacaoClube;

    private String estrelaDoClube;
}
