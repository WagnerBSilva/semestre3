package school.sptech.projeto04jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projeto04JpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Projeto04JpaApplication.class, args);
	}

}
